import { HighlightPriceDirective } from './highlight-price.directive';

describe('HighlightPriceDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightPriceDirective();
    expect(directive).toBeTruthy();
  });
});
